function renderAnalysisView(container, store) {
    const rawRecords = store.getAllRecordsArray();
    
    // Si no hay datos, mostrar mensaje
    if(rawRecords.length === 0) {
        container.innerHTML = `
            <div class="view-header"><h1>Análisis Financiero</h1></div>
            <div style="text-align: center; padding: 3rem; color: var(--text-secondary);">
                <i class="fa-solid fa-chart-line" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                <h2>No hay datos suficientes</h2>
                <p>Agrega registros diarios para poder ver tu rendimiento.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div class="view-header" style="margin-bottom: 2rem;">
            <h1 style="font-size: 2rem;">Análisis de Rendimiento</h1>
        </div>
        
        <div class="charts-grid" style="display: grid; grid-template-columns: 1fr; gap: 2rem; @media(min-width: 1024px) { grid-template-columns: 1fr 1fr; }">
            
            <!-- Tendencia de los Últimos 7 Días -->
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h3 style="margin-bottom: 1rem; color: var(--text-primary); font-size: 1.125rem;">Últimos 7 Días</h3>
                <canvas id="chart-7days"></canvas>
            </div>
            
            <!-- Días más rentables de la semana -->
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h3 style="margin-bottom: 1rem; color: var(--text-primary); font-size: 1.125rem;">Promedio Neto por Día de Semana</h3>
                <canvas id="chart-weekdays"></canvas>
            </div>
            
            <!-- Comparativa Ingresos vs Egresos (Mensual) -->
             <div class="card" style="grid-column: 1 / -1; background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h3 style="margin-bottom: 1rem; color: var(--text-primary); font-size: 1.125rem;">Comparativa Histórica (Ingresos y Gastos)</h3>
                <canvas id="chart-history"></canvas>
            </div>
        </div>
    `;

    // Preparar Datos para los gráficos
    // 1. Últimos 7 días
    const sortedDesc = [...rawRecords].sort((a,b) => new Date(a.date) - new Date(b.date));
    const last7 = sortedDesc.slice(-7);
    
    const rootStyles = getComputedStyle(document.documentElement);
    const colorIncome = rootStyles.getPropertyValue('--color-income').trim() || '#10b981';
    const colorExpense = rootStyles.getPropertyValue('--color-expense').trim() || '#ef4444';
    const colorNet = rootStyles.getPropertyValue('--color-accent').trim() || '#6366f1';

    new Chart(document.getElementById('chart-7days'), {
        type: 'line',
        data: {
            labels: last7.map(r => new Date(r.date).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric' })),
            datasets: [{
                label: 'Ingreso Neto',
                data: last7.map(r => r.netIncome),
                borderColor: colorNet,
                backgroundColor: colorNet + '33', // 20% opacity approx en hex
                tension: 0.3,
                fill: true
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });

    // 2. Agrupación por Día de la Semana (0-Dom, 6-Sab)
    const weekDaysGroup = [0,0,0,0,0,0,0];
    const weekDaysCount = [0,0,0,0,0,0,0];
    
    rawRecords.forEach(r => {
        weekDaysGroup[r.dayOfWeek] += r.netIncome;
        weekDaysCount[r.dayOfWeek]++;
    });

    const weekDaysAvg = weekDaysGroup.map((total, i) => weekDaysCount[i] > 0 ? total / weekDaysCount[i] : 0);
    const daysLabels = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    new Chart(document.getElementById('chart-weekdays'), {
        type: 'bar',
        data: {
            labels: daysLabels,
            datasets: [{
                label: 'Promedio ($)',
                data: weekDaysAvg,
                backgroundColor: colorIncome,
                borderRadius: 4
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });

    // 3. Histórico General a manera de stacked bar o mixed chart para comparar volumenes.
    // Limitando a ultimos 14 registros para claridad
    const historyData = sortedDesc.slice(-14);
    
    new Chart(document.getElementById('chart-history'), {
        type: 'bar',
        data: {
            labels: historyData.map(r => new Date(r.date).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })),
            datasets: [
                {
                    label: 'Ingreso',
                    data: historyData.map(r => r.income),
                    backgroundColor: colorIncome,
                },
                {
                    label: 'Egreso',
                    data: historyData.map(r => r.totalExpenses),
                    backgroundColor: colorExpense,
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                x: { stacked: true },
                y: { stacked: true }
            }
        }
    });
}
