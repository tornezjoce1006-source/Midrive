// Inicializar Store Global
window.store = new DataStore();

document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

function initApp() {
    setupNavigation();
    
    // Vista por defecto
    navigateTo('dashboard');
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a');
    const sidebar = document.getElementById('sidebar');
    const menuToggle = document.getElementById('menu-toggle');

    // Toggle móvil
    if(menuToggle) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    const activateLink = (viewId) => {
        navLinks.forEach(l => l.classList.remove('active'));
        const target = document.querySelector(`.nav-links a[data-view="${viewId}"]`);
        if(target) target.classList.add('active');
    };

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Cerrar menú móvil al hacer click
            if (window.innerWidth < 1024) {
                 sidebar.classList.remove('open');
            }

            const viewId = e.currentTarget.getAttribute('data-view');
            activateLink(viewId);
            navigateTo(viewId);
        });
    });

    // Custom Event Listener para navegaciones programáticas
    window.addEventListener('nav-to-record', (e) => {
        const dateClicked = e.detail.date;
        activateLink('records');
        navigateTo('records', { dateId: dateClicked });
    });
}

function navigateTo(viewId, params = null) {
    const mainContent = document.querySelector('.main-content');
    
    // Limpiar container
    mainContent.innerHTML = '';
    
    // Lógica condicional de renderizado
    switch(viewId) {
        case 'dashboard':
            renderDashboard(mainContent);
            break;
        case 'records':
            renderRecordsView(mainContent, window.store);
            // Si pasaron parámetros de fecha
            if(params && params.dateId) {
                const dateSelector = document.getElementById('date-selector');
                if(dateSelector) {
                    dateSelector.value = params.dateId;
                    dateSelector.dispatchEvent(new Event('change'));
                }
            }
            break;
        case 'calendar':
            renderCalendarView(mainContent, window.store);
            break;
        case 'analysis':
            // Small timeout to allow Doms to exist before Chart.js paints
            renderAnalysisView(mainContent, window.store);
            break;
        default:
            renderDashboard(mainContent);
    }
}

// ------ Dashboard Principal ------

function renderDashboard(container) {
    const rawRecords = window.store.getAllRecordsArray();
    
    // Obtener la semana y año actual
    const today = new Date();
    const currentWeekNumber = window.store.getWeekNumber(today);
    const currentYear = today.getFullYear();

    // Filtrar solo los registros de la semana actual
    const records = rawRecords.filter(r => r.weekNumber === currentWeekNumber && r.year === currentYear);

    const totalIncome = records.reduce((sum, r) => sum + r.income, 0);
    const totalExp = records.reduce((sum, r) => sum + r.totalExpenses, 0);
    const totalNet = records.reduce((sum, r) => sum + r.netIncome, 0);

    // Encontrar mejor día
    let bestDay = null;
    let maxNet = -Infinity;
    records.forEach(r => {
        if(r.netIncome > maxNet) {
            maxNet = r.netIncome;
            bestDay = r;
        }
    });

    const isPositive = totalNet >= 0;
    const netColor = isPositive ? 'var(--color-income)' : 'var(--color-expense)';

    container.innerHTML = `
        <div class="view-header" style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 1.5rem;">
            <div>
                <h1 style="font-size: 2rem; color: var(--text-primary); margin-bottom: 0.25rem;">Resumen de la Semana</h1>
                <p style="color: var(--text-secondary); font-size: 0.875rem;">Semana en curso (del año ${currentYear})</p>
            </div>
        </div>
        <div class="dashboard-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <h3 style="color: var(--text-secondary); font-size: 0.875rem; text-transform: uppercase;">Ingresos Totales</h3>
                    <div style="width:32px; height:32px; border-radius: 50%; background: var(--color-income-light); color: var(--color-income); display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-arrow-trend-up"></i></div>
                </div>
                <p style="font-size: 2rem; font-weight: 700; color: var(--text-primary);">$${totalIncome.toFixed(2)}</p>
            </div>
            
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <h3 style="color: var(--text-secondary); font-size: 0.875rem; text-transform: uppercase;">Egresos Totales</h3>
                    <div style="width:32px; height:32px; border-radius: 50%; background: var(--color-expense-light); color: var(--color-expense); display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-arrow-trend-down"></i></div>
                </div>
                <p style="font-size: 2rem; font-weight: 700; color: var(--text-primary);">$${totalExp.toFixed(2)}</p>
            </div>
            
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md); border-left: 4px solid ${netColor};">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <h3 style="color: var(--text-secondary); font-size: 0.875rem; text-transform: uppercase;">Ingreso Neto</h3>
                    <div style="width:32px; height:32px; border-radius: 50%; background: ${totalNet >= 0 ? 'var(--color-income-light)' : 'var(--color-expense-light)'}; color: ${netColor}; display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-wallet"></i></div>
                </div>
                <p style="font-size: 2rem; font-weight: 700; color: ${netColor};">$${totalNet.toFixed(2)}</p>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr; gap: 2rem; @media(min-width: 1024px) { grid-template-columns: 1fr 1fr; }">
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h3 style="margin-bottom: 1rem; color: var(--text-primary); font-size: 1.125rem;"><i class="fa-solid fa-trophy" style="color: #fbbf24; margin-right: 0.5rem;"></i> Día Más Rentable</h3>
                ${bestDay && bestDay.netIncome > 0 ? `
                    <div style="display: flex;justify-content: space-between; align-items: center; padding: 1rem; background: var(--bg-primary); border-radius: var(--radius-md);">
                        <div>
                            <p style="font-weight: 600; color: var(--text-primary);">${new Date(bestDay.date).toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        </div>
                        <div style="font-size: 1.5rem; font-weight: 700; color: var(--color-income);">+$${bestDay.netIncome.toFixed(2)}</div>
                    </div>
                ` : `<p style="color: var(--text-secondary);">Aún no hay días con saldo positivo.</p>`}
            </div>

            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h3 style="margin-bottom: 1rem; color: var(--text-primary); font-size: 1.125rem;"><i class="fa-solid fa-scale-balanced" style="color: var(--color-accent); margin-right: 0.5rem;"></i> Promedios Diarios (Semana)</h3>
                 ${records.length > 0 ? `
                     <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px dashed var(--border-color);">
                            <span style="color: var(--text-secondary);">Ingreso Promedio:</span>
                            <span style="font-weight: 600;">$${(totalIncome / records.length).toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: 0.5rem; border-bottom: 1px dashed var(--border-color);">
                            <span style="color: var(--text-secondary);">Gasto Promedio:</span>
                            <span style="font-weight: 600;">$${(totalExp / records.length).toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="color: var(--text-secondary);">Neto Promedio:</span>
                            <span style="font-weight: 700; color: ${totalNet >= 0 ? 'var(--color-income)' : 'var(--color-expense)'};">$${(totalNet / records.length).toFixed(2)}</span>
                        </div>
                    </div>
                 ` : `<p style="color: var(--text-secondary);">Aún no hay registros en esta semana.</p>`}
            </div>
        </div>
    `;
}
