function renderCalendarView(container, store) {
    const today = new Date();
    let currentMonth = today.getMonth();
    let currentYear = today.getFullYear();
    
    // Función de renderizado principal
    const render = () => {
        container.innerHTML = `
            <div class="view-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h1 style="font-size: 2rem;">Calendario</h1>
                <div style="display: flex; gap: 1rem; align-items: center;">
                    <button id="prev-month" style="background: var(--bg-secondary); border: 1px solid var(--border-color); color: var(--text-primary); padding: 0.5rem; border-radius: var(--radius-md); cursor: pointer;"><i class="fa-solid fa-chevron-left"></i></button>
                    <h2 style="font-size: 1.25rem; font-weight: 600; min-width: 150px; text-align: center;">
                        ${new Date(currentYear, currentMonth).toLocaleDateString('es-ES', { month: 'long', year: 'numeric' })}
                    </h2>
                    <button id="next-month" style="background: var(--bg-secondary); border: 1px solid var(--border-color); color: var(--text-primary); padding: 0.5rem; border-radius: var(--radius-md); cursor: pointer;"><i class="fa-solid fa-chevron-right"></i></button>
                </div>
            </div>
            
            <div class="calendar-grid bg-secondary" style="background: var(--bg-secondary); border-radius: var(--radius-lg); box-shadow: var(--shadow-md); overflow: hidden;">
                <!-- Días de la semana -->
                <div style="display: grid; grid-template-columns: repeat(7, 1fr); background: var(--bg-primary); border-bottom: 1px solid var(--border-color);">
                    ${['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map(day => `
                        <div style="padding: 1rem 0; text-align: center; font-weight: 600; color: var(--text-secondary); font-size: 0.875rem;">${day}</div>
                    `).join('')}
                </div>
                
                <!-- Cuadrícula de días -->
                <div id="calendar-days" style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 1px; background: var(--border-color);">
                    <!-- Generado dinámicamente -->
                </div>
            </div>
            
            <!-- Resumen del Mes -->
            <div class="card" style="margin-top: 2rem; background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h3 style="margin-bottom: 1rem; color: var(--text-primary);">Resumen Mensual</h3>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; text-align: center;">
                    <div>
                        <p style="color: var(--text-secondary); font-size: 0.875rem;">Ingresos</p>
                        <p id="month-income" style="color: var(--color-income); font-weight: 700; font-size: 1.25rem;">$0.00</p>
                    </div>
                    <div style="border-left: 1px solid var(--border-color); border-right: 1px solid var(--border-color);">
                        <p style="color: var(--text-secondary); font-size: 0.875rem;">Egresos</p>
                        <p id="month-expense" style="color: var(--color-expense); font-weight: 700; font-size: 1.25rem;">$0.00</p>
                    </div>
                    <div>
                        <p style="color: var(--text-secondary); font-size: 0.875rem;">Balance Neto</p>
                        <p id="month-net" style="font-weight: 700; font-size: 1.25rem;">$0.00</p>
                    </div>
                </div>
            </div>
        `;

        generateCalendarDays();
        
        // Eventos de Navegación del Calendario
        document.getElementById('prev-month').addEventListener('click', () => {
            currentMonth--;
            if(currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            render();
        });

        document.getElementById('next-month').addEventListener('click', () => {
            currentMonth++;
            if(currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            render();
        });
    };

    const generateCalendarDays = () => {
        const daysContainer = document.getElementById('calendar-days');
        const firstDay = new Date(currentYear, currentMonth, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        
        // Cálculos del mes
        let mIncome = 0;
        let mExpense = 0;
        let mNet = 0;

        let daysHtml = '';
        
        // Cajas vacías al principio
        for(let i = 0; i < firstDay; i++) {
            daysHtml += `<div style="background: var(--bg-primary); min-height: 100px;"></div>`;
        }
        
        // Días reales
        for(let displayDay = 1; displayDay <= daysInMonth; displayDay++) {
            // Check si hay registro
            const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(displayDay).padStart(2, '0')}`;
            const record = store.records[dateStr];
            
            let isTodayStr = dateStr === store.generateId(today) ? `border: 2px solid var(--color-accent);` : '';
            let contentHtml = '';
            
            if (record && (record.income > 0 || record.totalExpenses > 0)) {
                mIncome += record.income;
                mExpense += record.totalExpenses;
                mNet += record.netIncome;

                let badgeColor = 'var(--text-secondary)';
                if (record.netIncome > 0) badgeColor = 'var(--color-income)';
                else if (record.netIncome < 0) badgeColor = 'var(--color-expense)';

                contentHtml = `
                    <div style="font-size: 0.75rem; margin-top: 0.5rem; text-align: center;">
                        <span style="display: block; color: var(--color-income);">+$${record.income.toFixed(0)}</span>
                        <span style="display: block; color: var(--color-expense);">-$${record.totalExpenses.toFixed(0)}</span>
                        <span style="display: inline-block; margin-top: 0.25rem; padding: 2px 6px; border-radius: var(--radius-sm); background: ${badgeColor}; color: white; font-weight: 600;">$${record.netIncome.toFixed(0)}</span>
                    </div>
                `;
            }

            daysHtml += `
                <div class="calendar-day" data-date="${dateStr}" style="background: var(--bg-secondary); padding: 0.5rem; min-height: 100px; cursor: pointer; transition: background var(--transition-fast); ${isTodayStr}">
                    <div style="font-weight: 500; font-size: 0.875rem; color: var(--text-primary);">${displayDay}</div>
                    ${contentHtml}
                </div>
            `;
        }

        daysContainer.innerHTML = daysHtml;

        // Actualizar Resumen
        document.getElementById('month-income').innerText = `$${mIncome.toFixed(2)}`;
        document.getElementById('month-expense').innerText = `$${mExpense.toFixed(2)}`;
        document.getElementById('month-net').innerText = `$${mNet.toFixed(2)}`;
        
        const netEl = document.getElementById('month-net');
        netEl.style.color = mNet >= 0 ? 'var(--color-income)' : 'var(--color-expense)';

        // Click en un día nos lleva a la vista de registros para ese día
        document.querySelectorAll('.calendar-day').forEach(el => {
            el.addEventListener('click', (e) => {
                const dateClicked = e.currentTarget.dataset.date;
                // Pequeño hack para cambiar de vista desde aquí despachando evento o llamando función global:
                // Para esto podemos disparar un evento personalizado
                window.dispatchEvent(new CustomEvent('nav-to-record', { detail: { date: dateClicked }}));
            });
        });
    };

    render();
}
