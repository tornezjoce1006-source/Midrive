// Componente de Vista: Día a Día (Registros)
function renderRecordsView(container, store) {
    // Fecha seleccionada en la UI
    // Por defecto hoy
    let currentDateId = store.generateId(new Date());
    let currentRecord = store.getRecord(currentDateId);

    // Renderizar estructura básica
    container.innerHTML = `
        <div class="view-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1 style="font-size: 2rem;">Día a Día</h1>
            <input type="date" id="date-selector" value="${currentDateId}" 
                   style="padding: 0.5rem 1rem; border-radius: var(--radius-md); border: 1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-primary); font-family: var(--font-family);">
        </div>
        
        <div class="records-grid" style="display: grid; grid-template-columns: 1fr; gap: 2rem; @media(min-width: 1024px) { grid-template-columns: 1fr 1fr; }">
            
            <!-- Formulario de Ingresos -->
            <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <h2 style="font-size: 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem; color: var(--color-income);">
                    <i class="fa-solid fa-money-bill-wave"></i> Ingresos del Día
                </h2>
                
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem; color: var(--text-secondary); font-size: 0.875rem;">Total Generado ($)</label>
                    <input type="number" id="income-input" value="${currentRecord.income}" step="0.01" min="0"
                           style="width: 100%; padding: 0.75rem; border-radius: var(--radius-md); border: 1px solid var(--border-color); background: var(--bg-primary); color: var(--text-primary); font-size: 1.125rem;">
                </div>
            </div>

            <!-- Egresos (Gastos) -->
             <div class="card" style="background: var(--bg-secondary); padding: 1.5rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2 style="font-size: 1.25rem; display: flex; align-items: center; gap: 0.5rem; color: var(--color-expense);">
                        <i class="fa-solid fa-gas-pump"></i> Egresos
                    </h2>
                    <button id="add-expense-btn" style="background: var(--color-accent); color: white; border: none; padding: 0.5rem 1rem; border-radius: var(--radius-md); cursor: pointer; font-size: 0.875rem; transition: background var(--transition-fast);">
                        <i class="fa-solid fa-plus"></i> Añadir Gasto
                    </button>
                </div>
                
                <div id="expenses-list" style="display: flex; flex-direction: column; gap: 1rem;">
                    <!-- Los gastos se inyectarán aquí -->
                </div>
                
                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px dashed var(--border-color); display: flex; justify-content: space-between; font-weight: 700;">
                    <span>Total Egresos:</span>
                    <span style="color: var(--color-expense);">$<span id="total-expenses-display">${currentRecord.totalExpenses.toFixed(2)}</span></span>
                </div>
            </div>
            
            <!-- Resumen del Día -->
            <div class="card summary-card" style="grid-column: 1 / -1; background: var(--color-neutral); color: white; padding: 2rem; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); text-align: center;">
                <h2 style="font-size: 1.25rem; margin-bottom: 1rem; font-weight: 500;">Ingreso Neto del Día</h2>
                <div style="font-size: 3.5rem; font-weight: 700; line-height: 1;">
                    $<span id="net-income-display">${currentRecord.netIncome.toFixed(2)}</span>
                </div>
            </div>
            
        </div>
    `;

    // Inicializar lógica de eventos visuales
    const dateSelector = document.getElementById('date-selector');
    const incomeInput = document.getElementById('income-input');
    const addExpenseBtn = document.getElementById('add-expense-btn');
    const expensesList = document.getElementById('expenses-list');
    
    // Renderizado interno de gastos (estado local mutable para la UI)
    let tempExpenses = [...currentRecord.expenses];

    const EXPENSE_TYPES = {
        'gas': { label: 'Gasolina', icon: 'fa-gas-pump' },
        'food': { label: 'Comida', icon: 'fa-utensils' },
        'tuition': { label: 'Colegiatura', icon: 'fa-graduation-cap' },
        'internet': { label: 'Internet', icon: 'fa-wifi' },
        'water': { label: 'Agua', icon: 'fa-faucet-drip' },
        'electricity': { label: 'Luz', icon: 'fa-bolt' },
        'maint_prev': { label: 'Mantenimiento preventivo', icon: 'fa-wrench' },
        'maint_corr': { label: 'Mantenimiento correctivo', icon: 'fa-screwdriver-wrench' },
        'rent': { label: 'Renta', icon: 'fa-house' },
        'phone': { label: 'Plan telefónico', icon: 'fa-mobile-screen' },
        'other': { label: 'Otros', icon: 'fa-receipt' }
    };

    const renderExpenses = () => {
        expensesList.innerHTML = '';
        if(tempExpenses.length === 0) {
            expensesList.innerHTML = '<p style="color: var(--text-secondary); text-align: center; font-size: 0.875rem; padding: 1rem 0;">No has registrado gastos hoy.</p>';
        } else {
            tempExpenses.forEach((exp, index) => {
                const el = document.createElement('div');
                el.style.display = 'flex';
                el.style.gap = '0.75rem';
                el.style.alignItems = 'center';
                
                // Get Type Info from Enum or Default
                const typeInfo = EXPENSE_TYPES[exp.type] || EXPENSE_TYPES['other'];
                const icon = typeInfo.icon;
                
                let optionsHtml = '';
                for(const [key, val] of Object.entries(EXPENSE_TYPES)) {
                    const selected = exp.type === key ? 'selected' : '';
                    optionsHtml += `<option value="${key}" ${selected}>${val.label}</option>`;
                }
                
                el.innerHTML = `
                    <div style="width: 40px; height: 40px; flex-shrink: 0; border-radius: var(--radius-md); background: var(--color-expense-light); color: var(--color-expense); display: flex; align-items: center; justify-content: center;">
                        <i class="fa-solid ${icon}"></i>
                    </div>
                    <div style="flex: 1; min-width: 120px;">
                        <select class="exp-type-select" data-idx="${index}" style="width: 100%; padding: 0.5rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-primary); color: var(--text-primary); font-family: var(--font-family); outline: none; cursor: pointer;">
                            ${optionsHtml}
                        </select>
                    </div>
                    <div style="width: 100px; flex-shrink: 0;">
                        <input type="number" value="${exp.amount}" class="exp-amount" data-idx="${index}" step="0.01" min="0" placeholder="$0.00" style="width: 100%; padding: 0.5rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-primary); color: var(--text-primary);">
                    </div>
                    <button class="delete-exp-btn" data-idx="${index}" title="Eliminar gasto" style="background: transparent; color: var(--text-secondary); border: none; cursor: pointer; padding: 0.5rem; transition: color var(--transition-fast);">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                `;
                expensesList.appendChild(el);
            });
            
            // Re-vincular los eventos de los nuevos inputs generados
            bindExpenseEvents();
        }
        updateTotals();
    };

    const updateTotals = () => {
        const income = parseFloat(incomeInput.value || 0);
        const totalExp = tempExpenses.reduce((sum, e) => sum + parseFloat(e.amount || 0), 0);
        const net = income - totalExp;
        
        document.getElementById('total-expenses-display').innerText = totalExp.toFixed(2);
        
        const netDisplay = document.getElementById('net-income-display');
        netDisplay.innerText = net.toFixed(2);
        
        // Cambiar color del fondo basado en el neto
        const summaryCard = document.querySelector('.summary-card');
        if (net > 0) {
            summaryCard.style.background = 'var(--color-income)';
        } else if (net < 0) {
            summaryCard.style.background = 'var(--color-expense)';
        } else {
            summaryCard.style.background = 'var(--text-secondary)';
        }
        
        // Guardar automáticamente
        saveCurrentState();
    };

    const saveCurrentState = () => {
        const updatedRecord = {
            ...currentRecord,
            income: parseFloat(incomeInput.value || 0),
            expenses: tempExpenses
        };
        currentRecord = store.saveRecord(updatedRecord);
    };

    const bindExpenseEvents = () => {
        document.querySelectorAll('.exp-type-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const idx = e.target.dataset.idx;
                const newType = e.target.value;
                tempExpenses[idx].type = newType;
                tempExpenses[idx].name = EXPENSE_TYPES[newType].label;
                
                // Forzar re-render para actualizar el ícono
                renderExpenses(); 
            });
        });
        document.querySelectorAll('.exp-amount').forEach(input => {
            input.addEventListener('input', (e) => {
                tempExpenses[e.target.dataset.idx].amount = parseFloat(e.target.value || 0);
                updateTotals();
            });
        });
        document.querySelectorAll('.delete-exp-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = e.currentTarget.dataset.idx;
                if(confirm("¿Eliminar este gasto?")) {
                    tempExpenses.splice(idx, 1);
                    renderExpenses();
                }
            });
        });
    };

    // Eventos principales
    dateSelector.addEventListener('change', (e) => {
        currentDateId = e.target.value;
        currentRecord = store.getRecord(currentDateId);
        incomeInput.value = currentRecord.income;
        tempExpenses = [...currentRecord.expenses];
        renderExpenses();
    });

    incomeInput.addEventListener('input', updateTotals);

    addExpenseBtn.addEventListener('click', () => {
        // Modal simple mockeado con prompt o añadir fila directa
        // Implementemos añadir fila directa por UX fluida para conductores
        tempExpenses.push({
            id: Date.now().toString(),
            name: 'Gasolina', 
            amount: 0,
            type: 'gas'
        });
        renderExpenses();
    });

    // Render inicial local
    renderExpenses();
}
