/**
 * Estructura de Datos (TypeScript concepto):
 * 
 * interface Expense {
 *   id: string;
 *   name: string;
 *   amount: number;
 *   type: 'gas' | 'food' | 'other' | string;
 * }
 * 
 * interface DailyRecord {
 *   id: string; // YYYY-MM-DD
 *   date: string; // ISO string 
 *   income: number;
 *   expenses: Expense[];
 *   netIncome: number; // calculado
 *   totalExpenses: number; // calculado
 *   weekNumber: number; // calculado
 *   month: number; // 0-11
 *   year: number;
 *   dayOfWeek: number; // 0-6 (0 = Dom)
 * }
 */

class DataStore {
    constructor() {
        this.STORAGE_KEY = 'driver_finance_data';
        this.records = this.loadData();
        this.listeners = [];
    }

    // Cargar datos de LocalStorage
    loadData() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY);
            return data ? JSON.parse(data) : {};
        } catch (e) {
            console.error("Error cargando datos de LocalStorage", e);
            return {};
        }
    }

    // Guardar en LocalStorage
    saveData() {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.records));
            this.notify();
        } catch (e) {
            console.error("Error guardando datos en LocalStorage", e);
        }
    }

    // Suscripción a cambios (Observer Pattern para actulizar UIs)
    subscribe(listener) {
        this.listeners.push(listener);
        return () => {
            this.listeners = this.listeners.filter(l => l !== listener);
        };
    }

    notify() {
        this.listeners.forEach(listener => listener(this.records));
    }

    // Utilidades de Fechas
    getWeekNumber(date) {
        const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        const dayNum = d.getUTCDay() || 7;
        d.setUTCDate(d.getUTCDate() + 4 - dayNum);
        const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
        return Math.ceil((((d - yearStart) / 86400000) + 1)/7);
    }

    generateId(dateObj) {
        const year = dateObj.getFullYear();
        const month = String(dateObj.getMonth() + 1).padStart(2, '0');
        const day = String(dateObj.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Operaciones CRUD
    
    /**
     * Devuelve un registro específico o un formato vacío por defecto
     */
    getRecord(dateString) { // Formato YYYY-MM-DD
        if (this.records[dateString]) {
             return this.records[dateString];
        }
        
        // Crear plantilla vacía
        const [year, month, day] = dateString.split('-').map(Number);
        const dateObj = new Date(year, month - 1, day);
        
        return {
            id: dateString,
            date: dateObj.toISOString(),
            income: 0,
            expenses: [],
            netIncome: 0,
            totalExpenses: 0,
            weekNumber: this.getWeekNumber(dateObj),
            month: dateObj.getMonth(),
            year: dateObj.getFullYear(),
            dayOfWeek: dateObj.getDay()
        };
    }

    getAllRecordsArray() {
        return Object.values(this.records).sort((a, b) => new Date(b.date) - new Date(a.date));
    }

    /**
     * Guarda o actualiza un registro
     */
    saveRecord(recordData) {
        // Calcular totales antes de guardar
        const totalExpenses = recordData.expenses.reduce((sum, exp) => sum + parseFloat(exp.amount || 0), 0);
        const netIncome = parseFloat(recordData.income || 0) - totalExpenses;
        
        const updatedRecord = {
            ...recordData,
            totalExpenses,
            netIncome
        };

        this.records[updatedRecord.id] = updatedRecord;
        this.saveData();
        return updatedRecord;
    }

    deleteRecord(dateId) {
        if (this.records[dateId]) {
            delete this.records[dateId];
            this.saveData();
            return true;
        }
        return false;
    }
}
